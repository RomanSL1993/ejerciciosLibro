package libroFinalJCBD;

public class principalFinal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
//		if(GestorProyectos.agregarEmpleado("1234", "alguien")) {
//			System.out.println("Se ha agregado el empleado");
//		}else {
//			System.out.println("No se ha agregado al empleado");
//		}
		
		System.out.println("El proyecto num: "+GestorProyectos.nuevoProyecto("Crear empleado", "0000", null, null)+" se ha ejecutado");
	}

	
}
