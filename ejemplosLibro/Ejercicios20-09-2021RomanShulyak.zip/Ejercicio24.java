package ejemplosLibro;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class Ejercicio24 {
 
 private String file= "archivo.txt";
 
 public void writeFile () throws IOException{
  
  
  Writer write = null;
  
        try {
            write = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(file),"UTF8"));
            write.write("Este es un archivo con codificaci�n utf-8\n" +              
              "�ste es Beta: �\n" +
              "estos son letras con acento: �����");
            
        }
        catch(Exception e){
         e.printStackTrace();
        }
        
        finally{
         write.close();
        }
 }
 
 public void readFile () throws IOException{
  
  String stringCadena = "";
        new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), "UTF8"));        

        BufferedReader  in = new BufferedReader (new InputStreamReader (new FileInputStream (file), "utf-8"));
        try{            
            while ((stringCadena = in.readLine())!=null) {
                  System.out.println(stringCadena);
                  
            }                                    
        }
        catch (Exception e){

        }
        finally{            
          in.close();  
        }
  
 }
 

 /**
  * @param args
  * @throws IOException 
  */
 public static void main(String[] args) throws IOException {
  Ejercicio24 readandWriteCodingFiles = new Ejercicio24();
  readandWriteCodingFiles.writeFile(); 
  readandWriteCodingFiles.readFile();
 }

}
